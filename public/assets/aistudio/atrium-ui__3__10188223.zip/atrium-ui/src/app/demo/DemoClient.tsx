'use client';

import { useEffect, useState } from 'react';
import {
  AtriumLogo,
  Button,
  IconButton,
  LiquidButton,
  LiquidLoader,
  Menu,
  Segmented,
  Select,
  StatusDot,
  Toggle,
} from '../../atrium';
import { Bell, ChevronDown, Gift, Grid, Home, List, Lock, LogOut, Plus, Pulse, Refresh, Rocket, Sparkles, Zap } from './icons';
import './demo.css';

function Surface({ theme, name }: { theme: 'light' | 'dark'; name: string }) {
  const [unread, setUnread] = useState(5);
  const [mode, setMode] = useState('manager');
  const [view, setView] = useState('grid');
  const [period, setPeriod] = useState('daily');
  const [notify, setNotify] = useState(true);
  const [saved, setSaved] = useState(false);

  return (
    <section className="surface" data-atrium-theme={theme} data-testid={`surface-${theme}`}>
      <div className="surface-head">
        <span className="cap">{name}</span>
        <Menu
          aria-label="Account"
          header={
            <>
              <b>Mehdi Samih</b>
              <small>mehdi@example.com</small>
            </>
          }
          items={[
            { id: 'lock', label: 'Lock terminal / switch staff', icon: <Lock /> },
            { id: 'diag', label: 'Server diagnostics', description: 'Live audit of all services', icon: <Pulse /> },
            { id: 'wizard', label: 'New business onboarding', icon: <Rocket /> },
            { id: 'voucher', label: 'Redeem voucher', icon: <Gift /> },
            { type: 'separator' },
            { id: 'out', label: 'Sign out', icon: <LogOut />, danger: true },
          ]}
          trigger={(p) => (
            <Button {...p} tone="soft" trailing={<ChevronDown />} data-testid={`menu-${theme}`}>
              Mehdi
            </Button>
          )}
        />
      </div>

      <div className="row">
        <Button leading={<Plus />} data-testid={`accent-${theme}`}>
          Quick action
        </Button>
        <Button tone="outline" leading={<Sparkles />}>
          Demo data
        </Button>
        <Button tone="soft" leading={<Home />} trailing={<ChevronDown />}>
          Main branch
        </Button>
        <Button tone="accent" disabled>
          Disabled
        </Button>
      </div>

      <div className="row">
        <Segmented
          aria-label="Mode"
          value={mode}
          onValueChange={setMode}
          options={[
            { value: 'manager', label: 'Manager' },
            { value: 'scan', label: 'Welcome & scan', icon: <Zap /> },
          ]}
        />
        <Segmented
          aria-label="View"
          value={view}
          onValueChange={setView}
          options={[
            { value: 'list', icon: <List />, 'aria-label': 'List' },
            { value: 'grid', icon: <Grid />, 'aria-label': 'Grid' },
          ]}
        />
        <Segmented
          aria-label="Range"
          defaultValue="week"
          options={[
            { value: 'day', label: 'Day' },
            { value: 'week', label: 'Week' },
            { value: 'month', label: 'Month' },
          ]}
        />
        <Select
          aria-label="Period"
          value={period}
          onValueChange={setPeriod}
          options={[
            { value: 'daily', label: 'Daily' },
            { value: 'weekly', label: 'Weekly' },
            { value: 'monthly', label: 'Monthly' },
          ]}
        />
      </div>

      <div className="row">
        <IconButton aria-label="Refresh" icon={<Refresh />} kick="spin" data-testid={`refresh-${theme}`} />
        <IconButton
          aria-label={`Notifications, ${unread} unread`}
          icon={<Bell />}
          badge={unread}
          onClick={() => setUnread((n) => n + 1)}
          data-testid={`bell-${theme}`}
        />
        <Button tone="soft" leading={<StatusDot />} trailing={<ChevronDown />}>
          Online
        </Button>
        <Button tone="success" onClick={() => setSaved(true)}>
          {saved ? 'Synced' : 'Cloud sync'}
        </Button>
        <label className="switch-row">
          <Toggle aria-label="Notifications" checked={notify} onCheckedChange={setNotify} data-testid={`toggle-${theme}`} />
          <span>{notify ? 'On' : 'Off'}</span>
        </label>
      </div>

      <div className="show" data-testid={`show-${theme}`}>
        <span className="cap">Showpieces</span>
        <div className="show-grid">
          <LiquidButton kind="scan" data-testid={`lb-scan-${theme}`} />
          <LiquidButton kind="import" tone="ink" data-testid={`lb-import-${theme}`} />
          <LiquidButton kind="export" data-testid={`lb-export-${theme}`} />
          <LiquidButton kind="confirm" tone="ink" data-testid={`lb-confirm-${theme}`} />
          <LiquidButton kind="continue" data-testid={`lb-continue-${theme}`} />
          <LiquidButton kind="create" tone="ink" labels={{ idle: 'Create member', done: 'Member added' }} data-testid={`lb-create-${theme}`} />
          <AsyncDemo theme={theme} />
          <LoaderDemo theme={theme} />
        </div>
      </div>
    </section>
  );
}

/** A loader runs for as long as it is mounted and visible, so the demo lets you park it. Automated
 *  browsers start it parked so idle-cost checks measure the buttons, not the spinner. */
function LoaderDemo({ theme }: { theme: string }) {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(!navigator.webdriver), []);
  return (
    <span className="loader-cell">
      <LiquidLoader size={56} active={on} data-testid={`loader-${theme}`} />
      <label className="check">
        <input type="checkbox" checked={on} onChange={(e) => setOn(e.target.checked)} data-testid={`loader-run-${theme}`} /> running · click to stir
      </label>
    </span>
  );
}

/** Shows the real-app wiring: a promise decides how long the button is busy, and whether it fails. */
function AsyncDemo({ theme }: { theme: string }) {
  const [fail, setFail] = useState(false);
  const [pct, setPct] = useState<number | undefined>(undefined);
  return (
    <span className="async-cell">
      <LiquidButton
        kind="import"
        progress={pct}
        data-testid={`lb-async-${theme}`}
        labels={{ idle: 'Upload', busy: 'Uploading', done: 'Uploaded' }}
        onPress={async () => {
          for (let i = 1; i <= 5; i++) {
            await new Promise((r) => setTimeout(r, 350));
            setPct(i / 5);
          }
          setPct(undefined);
          if (fail) throw new Error('network');
        }}
      />
      <label className="check">
        <input type="checkbox" checked={fail} onChange={(e) => setFail(e.target.checked)} data-testid={`fail-${theme}`} /> make it fail
      </label>
    </span>
  );
}

export default function DemoClient() {
  const [h, setH] = useState(34);
  return (
    <main className="demo" style={{ ['--atr-h' as string]: `${h}px` }}>
      <header className="demo-head">
        <div>
          <AtriumLogo height={34} />
          <h1>One shape, any context</h1>
        </div>
        <label className="size">
          Control height
          <input type="range" min={24} max={44} step={1} value={h} onChange={(e) => setH(+e.target.value)} />
          <output>{h} px</output>
        </label>
      </header>
      <div className="grid">
        <Surface theme="light" name="Light surface" />
        <Surface theme="dark" name="Dark surface" />
      </div>
    </main>
  );
}

import DemoClient from './demo/DemoClient';

export default function Page() {
  return <DemoClient />;
}

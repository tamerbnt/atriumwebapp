// Real-browser checks for the Atrium controls.
//
//   BASE_URL=http://localhost:3000 node e2e/verify.mjs          (against `next dev` / `next start`)
//   SHOTS=./shots HEADED=1 node e2e/verify.mjs
//
// Needs `playwright` (and its Chromium). Exits non-zero if any check fails.
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const BASE = process.env.BASE_URL || 'http://localhost:3000';
const SHOTS = process.env.SHOTS || '';
if (SHOTS) mkdirSync(SHOTS, { recursive: true });

let failed = 0;
const results = [];
function check(name, ok, detail = '') {
  results.push({ name, ok, detail });
  if (!ok) failed++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await chromium.launch({ headless: !process.env.HEADED });

async function open({ reducedMotion = 'no-preference', width = 1440, height = 900 } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height }, reducedMotion });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => m.type() === 'error' && errors.push('console: ' + m.text()));
  // count animation frames so we can prove an idle page runs none
  await page.addInitScript(() => {
    const raf = window.requestAnimationFrame.bind(window);
    const caf = window.cancelAnimationFrame.bind(window);
    const live = new Set();
    window.__raf = { requested: 0, get pending() { return live.size; } };
    window.requestAnimationFrame = (cb) => {
      window.__raf.requested++;
      const id = raf((t) => { live.delete(id); cb(t); });
      live.add(id);
      return id;
    };
    window.cancelAnimationFrame = (id) => { live.delete(id); caf(id); };
  });
  await page.goto(BASE);
  await page.waitForSelector('[data-testid=surface-light]');
  await sleep(300);
  return { ctx, page, errors };
}

const L = (s) => `[data-testid=surface-light] ${s}`;
const D = (s) => `[data-testid=surface-dark] ${s}`;
const frames = (page) => page.evaluate(() => ({ requested: window.__raf.requested, pending: window.__raf.pending }));
const parseCircle = (s) => { const m = /circle\(([\d.]+)px/.exec(s || ''); return m ? parseFloat(m[1]) : null; };

/* ------------------------------------------------------------------ main run */
{
  const { ctx, page, errors } = await open();

  // --- loads clean, idle costs nothing
  check('page loads without console errors', errors.length === 0, errors.join(' | '));
  const a = await frames(page);
  await sleep(1200);
  const b = await frames(page);
  check('idle page requests zero animation frames', a.requested === b.requested && b.pending === 0, `requested ${a.requested}→${b.requested}, pending ${b.pending}`);

  // --- accent button: hover / press / click
  const btn = page.locator(L('[data-testid=accent-light]'));
  const box = await btn.boundingBox();
  await btn.hover();
  await sleep(120);
  const hov = await btn.evaluate((el) => ({ clip: el.querySelector('[data-atr-lq]').style.clipPath, tf: el.style.transform }));
  check('hover grows the liquid from the pointer', (parseCircle(hov.clip) || 0) > 2, hov.clip);
  check('hover leans the body (transform applied)', /translate/.test(hov.tf), hov.tf);
  await sleep(900);
  const idleHover = await frames(page);
  await sleep(400);
  const idleHover2 = await frames(page);
  check('steady hover goes back to sleep (no frames)', idleHover.requested === idleHover2.requested && idleHover2.pending === 0, `${idleHover.requested}→${idleHover2.requested}`);

  await page.mouse.down();
  await sleep(150);
  const pressed = await btn.evaluate((el) => el.style.transform);
  const sy = /scale\(([\d.]+),\s*([\d.]+)\)/.exec(pressed);
  check('press squashes the body (wider, shorter)', !!sy && +sy[1] > 1.005 && +sy[2] < 0.99, pressed);
  await page.mouse.up();
  // sample the flood after the click
  const maxR = await btn.evaluate(async (el) => {
    const lq = el.querySelector('[data-atr-lq]');
    let max = 0;
    const end = performance.now() + 500;
    await new Promise((res) => {
      const tick = () => {
        const m = /circle\(([\d.]+)px/.exec(lq.style.clipPath || '');
        if (m) max = Math.max(max, parseFloat(m[1]));
        performance.now() < end ? requestAnimationFrame(tick) : res();
      };
      tick();
    });
    return max;
  });
  check('click floods the whole button', maxR >= box.width * 0.9, `max radius ${maxR.toFixed(0)}px vs width ${box.width.toFixed(0)}px`);

  await page.mouse.move(5, 5);
  await sleep(1200);
  const rest = await btn.evaluate((el) => ({ clip: el.querySelector('[data-atr-lq]').style.clipPath, tf: el.style.transform, wc: el.style.willChange }));
  const f3 = await frames(page);
  check('leaving drains the liquid and clears every inline transform', (parseCircle(rest.clip) || 0) < 0.5 && rest.tf === '' && rest.wc === '', JSON.stringify(rest));
  check('…and the loop is asleep again', f3.pending === 0);

  // keyboard activation floods from the centre
  await btn.focus();
  await page.keyboard.press('Enter');
  await sleep(100);
  const kb = await btn.evaluate((el) => el.querySelector('[data-atr-lq]').style.clipPath);
  check('keyboard activation floods from the centre', /at 50|at [\d.]+px/.test(kb) && (parseCircle(kb) || 0) > 1, kb);
  await sleep(900);

  // --- disabled button never reacts
  const dis = page.locator(L('button:disabled'));
  await dis.hover({ force: true });
  await sleep(150);
  const disTf = await dis.evaluate((el) => el.style.transform);
  check('disabled button does not react', disTf === '', disTf);
  await page.mouse.move(5, 5);

  // --- segmented control (2 options): click, state, blob lands on the option
  const mode = page.locator(L('[role=radiogroup][aria-label=Mode]'));
  check('segmented blob is live after mount', (await mode.getAttribute('data-live')) === 'true');
  await mode.locator('[role=radio]').nth(1).click();
  await sleep(1000);
  const seg = await mode.evaluate((g) => {
    const blob = g.querySelector('span');
    const m = /inset\(0(?:px)? ([\d.]+)px 0(?:px)? ([\d.]+)px/.exec(blob.style.clipPath);
    const opts = [...g.querySelectorAll('[role=radio]')];
    const pad = parseFloat(getComputedStyle(blob).left);
    const o = opts[1];
    return {
      right: m && +m[1], left: m && +m[2],
      wantL: o.offsetLeft - pad, wantR: blob.offsetWidth - (o.offsetLeft - pad + o.offsetWidth),
      checked: opts.map((x) => x.getAttribute('aria-checked')),
      colorActive: getComputedStyle(o).color, colorIdle: getComputedStyle(opts[0]).color,
    };
  });
  check('clicking an option selects it (aria-checked)', seg.checked.join() === 'false,true', seg.checked.join());
  check('blob settles exactly over the chosen option', seg && Math.abs(seg.left - seg.wantL) < 0.6 && Math.abs(seg.right - seg.wantR) < 0.6, JSON.stringify({ l: seg.left, wl: seg.wantL, r: seg.right, wr: seg.wantR }));
  const dmode = page.locator(D('[role=radiogroup][aria-label=Mode]'));
  const c0 = await dmode.locator('[role=radio]').nth(1).evaluate((el) => getComputedStyle(el).color);
  await dmode.locator('[role=radio]').nth(1).click();
  await sleep(1300);
  const c1 = await dmode.locator('[role=radio]').nth(1).evaluate((el) => getComputedStyle(el).color);
  check('label colour flips to on-accent as the blob covers it (dark surface)', c0 !== c1, `${c0} → ${c1}`);

  // keyboard: arrows move + roving tabindex
  await mode.locator('[role=radio]').nth(1).focus();
  await page.keyboard.press('ArrowLeft');
  await sleep(50);
  const kseg = await mode.evaluate((g) => ({ checked: [...g.querySelectorAll('[role=radio]')].map((x) => x.getAttribute('aria-checked')), tab: [...g.querySelectorAll('[role=radio]')].map((x) => x.tabIndex), focus: document.activeElement.textContent }));
  check('arrow keys move the selection and focus', kseg.checked.join() === 'true,false' && /Manager/.test(kseg.focus), JSON.stringify(kseg));
  check('roving tabindex (only the selected option is tabbable)', kseg.tab.join() === '0,-1', kseg.tab.join());
  await sleep(900);

  // --- physics in a real browser: 3-option control, leading edge overshoots ≈ 8.5 %
  const range = page.locator(L('[role=radiogroup][aria-label=Range]'));
  const ov = await range.evaluate(async (g) => {
    const blob = g.querySelector('span');
    const opts = [...g.querySelectorAll('[role=radio]')];
    const pad = parseFloat(getComputedStyle(blob).left);
    const W = blob.offsetWidth;
    const geo = opts.map((o) => [o.offsetLeft - pad, o.offsetLeft - pad + o.offsetWidth]);
    // currently on "Week" (index 1). Move to "Month" (2): the right edge is the leading one.
    const R0 = W - geo[1][1], R1 = W - geo[2][1];
    const samples = [];
    opts[2].click();
    const end = performance.now() + 1500;
    await new Promise((res) => {
      const tick = () => {
        const m = /inset\(0(?:px)? ([-\d.]+)px/.exec(blob.style.clipPath || '');
        if (m) samples.push(parseFloat(m[1]));
        performance.now() < end ? requestAnimationFrame(tick) : res();
      };
      tick();
    });
    return { R0, R1, min: Math.min(...samples), last: samples[samples.length - 1] };
  });
  // R shrinks toward 0 when moving right; the clamp at 0 hides overshoot only for the last option's own edge,
  // so measure the stretch on the way back (Month → Week), where the leading edge is the left one.
  const ovBack = await range.evaluate(async (g) => {
    const blob = g.querySelector('span');
    const opts = [...g.querySelectorAll('[role=radio]')];
    const pad = parseFloat(getComputedStyle(blob).left);
    const geo = opts.map((o) => [o.offsetLeft - pad, o.offsetLeft - pad + o.offsetWidth]);
    const L0 = geo[2][0], L1 = geo[1][0];
    const samples = [];
    opts[1].click();
    const end = performance.now() + 1500;
    await new Promise((res) => {
      const tick = () => {
        const m = /inset\(0(?:px)? [-\d.]+px 0(?:px)? ([-\d.]+)px/.exec(blob.style.clipPath || '');
        if (m) samples.push(parseFloat(m[1]));
        performance.now() < end ? requestAnimationFrame(tick) : res();
      };
      tick();
    });
    return { L0, L1, min: Math.min(...samples), last: samples[samples.length - 1] };
  });
  const over = (ovBack.L1 - ovBack.min) / (ovBack.L0 - ovBack.L1);
  check('leading edge overshoots ≈ 8.5 % (ζ = 1/φ) in a real browser', over > 0.04 && over < 0.14, `measured ${(over * 100).toFixed(1)} %`);
  check('…and settles on the target', Math.abs(ovBack.last - ovBack.L1) < 0.6, `last ${ovBack.last} target ${ovBack.L1}`);

  // --- icon kicks: badge bounce + refresh spin
  const bell = page.locator(L('[data-testid=bell-light]'));
  const badge = page.locator(L('[data-testid=bell-light]')).locator('xpath=following-sibling::span');
  const before = await badge.textContent();
  await bell.click();
  await sleep(60);
  const popTf = await badge.evaluate((el) => el.style.transform);
  await sleep(1200);
  const after = await badge.textContent();
  const popRest = await badge.evaluate((el) => el.style.transform);
  check('badge count increments and pops on a spring', +after === +before + 1 && /scale/.test(popTf) && popRest === '', `${before}→${after}, mid ${popTf}, rest "${popRest}"`);
  const ref = page.locator(L('[data-testid=refresh-light]'));
  await ref.click();
  await sleep(250);
  const spinTf = await ref.locator('svg').evaluate((el) => el.style.transform);
  check('refresh icon spins', /rotate\(([\d.]+)deg\)/.test(spinTf) && parseFloat(/rotate\(([\d.]+)/.exec(spinTf)[1]) > 5, spinTf);
  await sleep(2500);
  await page.mouse.move(5, 5);

  // --- menu (dark surface): theme carried into the portal, keyboard, Escape, drain
  const trig = page.locator(D('[data-testid=menu-dark]'));
  await trig.click();
  await sleep(900);
  const m1 = await page.evaluate(() => {
    const p = document.querySelector('[role=menu]');
    if (!p) return null;
    const r = p.getBoundingClientRect();
    return { theme: p.getAttribute('data-atrium-theme'), bg: getComputedStyle(p).backgroundColor, vis: p.style.visibility, inView: r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth, parent: p.parentElement.tagName, h: r.height, role: document.querySelectorAll('[role=menuitem]').length };
  });
  check('menu opens in a portal on <body>', !!m1 && m1.parent === 'BODY' && m1.vis === 'visible' && m1.h > 100, JSON.stringify(m1));
  check('portalled menu keeps the dark theme of its trigger', !!m1 && m1.theme === 'dark' && m1.bg === 'rgb(38, 36, 34)', m1 && `${m1.theme} ${m1.bg}`);
  check('menu stays inside the viewport', !!m1 && m1.inView);
  check('trigger reports aria-expanded', (await trig.getAttribute('aria-expanded')) === 'true');
  await sleep(900);
  const hoverFrames = await frames(page);
  check('open menu at rest is asleep', hoverFrames.pending === 0, `pending ${hoverFrames.pending}`);

  if (SHOTS) await page.screenshot({ path: `${SHOTS}/menu-open.png` });

  await page.keyboard.press('ArrowDown'); // focus is still on the trigger: should move into the panel
  await sleep(50);
  const f1 = await page.evaluate(() => document.activeElement.textContent);
  await page.keyboard.press('ArrowDown');
  const f2 = await page.evaluate(() => document.activeElement.textContent);
  await page.keyboard.press('End');
  const f3b = await page.evaluate(() => document.activeElement.textContent);
  check('arrows move through rows, End jumps to the last', /Lock/.test(f1) && /diagnostics/i.test(f2) && /Sign out/.test(f3b), `${f1} | ${f2} | ${f3b}`);
  await sleep(150);
  const hl = await page.evaluate(() => { const h = document.querySelector('[role=menu] span[aria-hidden]'); return { op: parseFloat(h.style.opacity), h: parseFloat(h.style.height) }; });
  check('hover blob follows keyboard focus', hl.op > 0.5 && hl.h > 10, JSON.stringify(hl));
  await page.keyboard.type('n'); // type-ahead
  const fta = await page.evaluate(() => document.activeElement.textContent);
  check('type-ahead jumps to a matching row', /New business/.test(fta), fta);
  await page.keyboard.press('Escape');
  await sleep(50);
  const focusBack = await page.evaluate(() => document.activeElement.getAttribute('data-testid'));
  check('Escape closes the menu and returns focus to the trigger', focusBack === 'menu-dark', focusBack);
  await sleep(1200);
  const gone = await page.evaluate(() => document.querySelectorAll('[role=menu]').length);
  check('closed menu is removed from the DOM after it drains', gone === 0, `${gone} left`);

  // outside click closes, pointer-opened
  await trig.click();
  await sleep(500);
  await page.mouse.click(20, 20);
  await sleep(1200);
  const gone2 = await page.evaluate(() => document.querySelectorAll('[role=menu]').length);
  check('clicking outside closes the menu', gone2 === 0);

  // reopen during the drain: interruptible
  await trig.click();
  await sleep(700);
  await page.keyboard.press('Escape');
  await sleep(120);
  await trig.click();
  await sleep(900);
  const reopened = await page.evaluate(() => { const p = document.querySelector('[role=menu]'); return p && p.style.visibility; });
  check('re-opening mid-drain works (interruptible)', reopened === 'visible', String(reopened));
  await page.keyboard.press('Escape');
  await sleep(1200);

  // --- select
  const sel = page.locator(L('button[aria-haspopup=listbox]'));
  await sel.focus();
  await page.keyboard.press('ArrowDown');
  await sleep(700);
  const lb = await page.evaluate(() => { const p = document.querySelector('[role=listbox]'); return p && { n: p.querySelectorAll('[role=option]').length, sel: p.querySelector('[aria-selected=true]').textContent, focus: document.activeElement.textContent }; });
  check('select opens on the selected option (keyboard)', !!lb && lb.n === 3 && /Daily/.test(lb.sel) && /Daily/.test(lb.focus), JSON.stringify(lb));
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('Enter');
  await sleep(1200);
  const selTxt = await sel.textContent();
  check('choosing an option updates the trigger and closes', /Weekly/.test(selTxt) && (await page.evaluate(() => document.querySelectorAll('[role=listbox]').length)) === 0, selTxt);
  check('focus returns to the select trigger', await sel.evaluate((el) => el === document.activeElement));

  // --- toggle
  const tg = page.locator(L('[data-testid=toggle-light]'));
  check('toggle starts on (controlled)', (await tg.getAttribute('aria-checked')) === 'true');
  await tg.click();
  await sleep(100);
  const mid = await tg.evaluate((b) => ({ k: b.querySelector('span span:nth-child(2)').style.transform, p: b.querySelector('span span').style.clipPath, t: b.querySelector('span').style.transform }));
  check('toggle animates (knob + pool + tilt written by the engine)', /translate/.test(mid.k) && /inset/.test(mid.p) && /rotate/.test(mid.t), JSON.stringify(mid));
  await sleep(1200);
  const off = await tg.evaluate((b) => ({ c: b.getAttribute('aria-checked'), p: b.querySelector('span span').style.clipPath, h: b.querySelector('span').offsetHeight }));
  check('click turns it off and the pool rests on the left', off.c === 'false' && /inset\(0(px)? ([\d.]+)px 0(px)? 0px/.test(off.p), JSON.stringify(off));
  await tg.focus();
  await page.keyboard.press('Space');
  await sleep(1200);
  check('Space toggles it back on', (await tg.getAttribute('aria-checked')) === 'true');
  // drag: pull the pool to the left half
  const tb = await tg.boundingBox();
  await page.mouse.move(tb.x + tb.width * 0.75, tb.y + tb.height / 2);
  await page.mouse.down();
  await page.mouse.move(tb.x + tb.width * 0.2, tb.y + tb.height / 2, { steps: 8 });
  await page.mouse.up();
  await sleep(1200);
  check('dragging the pool past the middle switches it', (await tg.getAttribute('aria-checked')) === 'false');
  await page.mouse.move(5, 5);

  // --- one variable resizes everything, and the blob re-measures
  const slider = page.locator('input[type=range]');
  for (const size of [24, 44]) {
    await slider.evaluate((el, v) => { const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, String(v)); el.dispatchEvent(new Event('input', { bubbles: true })); }, size);
    await sleep(400);
    const h = await btn.evaluate((el) => el.getBoundingClientRect().height);
    const geo = await mode.evaluate((g) => {
      const blob = g.querySelector('span'); const m = /inset\(0(?:px)? ([\d.]+)px 0(?:px)? ([\d.]+)px/.exec(blob.style.clipPath);
      const o = g.querySelector('[aria-checked=true]'); const pad = parseFloat(getComputedStyle(blob).left);
      return { l: +m[2], want: o.offsetLeft - pad };
    });
    check(`control height ${size}px: buttons follow --atr-h`, Math.abs(h - size) < 0.6, `${h}px`);
    check(`control height ${size}px: segmented blob re-measures`, Math.abs(geo.l - geo.want) < 0.6, JSON.stringify(geo));
  }
  await slider.evaluate((el) => { const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, '34'); el.dispatchEvent(new Event('input', { bubbles: true })); });
  await sleep(300);

  if (SHOTS) {
    await page.screenshot({ path: `${SHOTS}/page.png`, fullPage: true });
    await btn.hover();
    await sleep(500);
    await page.screenshot({ path: `${SHOTS}/hover.png`, clip: { x: box.x - 40, y: box.y - 40, width: 700, height: 200 } });
  }

  // --- many frames of real interaction: how long does a frame take?
  const perf = await page.evaluate(async () => {
    const btns = [...document.querySelectorAll('button')].filter((b) => !b.disabled);
    const times = [];
    let last = performance.now();
    const end = last + 2500;
    let i = 0;
    await new Promise((res) => {
      const tick = (t) => {
        times.push(t - last); last = t;
        const b = btns[(i++ >> 3) % btns.length];
        const r = b.getBoundingClientRect();
        b.dispatchEvent(new PointerEvent('pointerover', { bubbles: true, clientX: r.left + 5, clientY: r.top + 5, pointerType: 'mouse' }));
        b.dispatchEvent(new PointerEvent('pointermove', { bubbles: true, clientX: r.left + (i % 20) * 3, clientY: r.top + 8, pointerType: 'mouse' }));
        t < end ? requestAnimationFrame(tick) : res();
      };
      requestAnimationFrame(tick);
    });
    times.shift();
    times.sort((a, b) => a - b);
    const avg = times.reduce((s, x) => s + x, 0) / times.length;
    return { avg, p95: times[Math.floor(times.length * 0.95)], max: times[times.length - 1], n: times.length, tier: window.__atrium.motion.tier };
  });
  check('sustained hover sweep across every button keeps frames short', perf.avg < 25, `avg ${perf.avg.toFixed(1)} ms, p95 ${perf.p95.toFixed(1)} ms, max ${perf.max.toFixed(1)} ms over ${perf.n} frames, tier ${perf.tier}`);
  await page.mouse.move(5, 5);
  await sleep(1500);

  await ctx.close();
}

/* ------------------------------------------------------------------ reduced motion */
{
  const { ctx, page } = await open({ reducedMotion: 'reduce' });
  const range = page.locator(L('[role=radiogroup][aria-label=Range]'));
  const over = await range.evaluate(async (g) => {
    const blob = g.querySelector('span');
    const opts = [...g.querySelectorAll('[role=radio]')];
    const pad = parseFloat(getComputedStyle(blob).left);
    const geo = opts.map((o) => [o.offsetLeft - pad, o.offsetLeft - pad + o.offsetWidth]);
    opts[2].click(); await new Promise((r) => setTimeout(r, 1200));
    const L0 = geo[2][0], L1 = geo[1][0];
    const samples = [];
    opts[1].click();
    const end = performance.now() + 1500;
    await new Promise((res) => {
      const tick = () => { const m = /inset\(0(?:px)? [-\d.]+px 0(?:px)? ([-\d.]+)px/.exec(blob.style.clipPath || ''); if (m) samples.push(parseFloat(m[1])); performance.now() < end ? requestAnimationFrame(tick) : res(); };
      tick();
    });
    return (L1 - Math.min(...samples)) / (L0 - L1);
  });
  check('prefers-reduced-motion: no overshoot (critically damped)', over < 0.005, `${(over * 100).toFixed(2)} %`);
  const bell = page.locator(L('[data-testid=bell-light]'));
  const badge = bell.locator('xpath=following-sibling::span');
  await bell.click();
  await sleep(80);
  check('prefers-reduced-motion: no badge pop', (await badge.evaluate((el) => el.style.transform)) === '');
  await ctx.close();
}

/* ------------------------------------------------------------------ tier "off" */
{
  const { ctx, page } = await open();
  await page.evaluate(() => window.__atrium.configureMotion({ tier: 'off' }));
  const btn = page.locator(L('[data-testid=accent-light]'));
  await btn.hover();
  await sleep(200);
  const st = await btn.evaluate((el) => ({ tf: el.style.transform, inline: el.querySelector('[data-atr-lq]').style.clipPath, css: getComputedStyle(el.querySelector('[data-atr-lq]')).clipPath, attr: document.documentElement.getAttribute('data-atr-motion') }));
  check('tier "off": engine writes nothing, CSS :hover carries the feedback', st.tf === '' && st.inline === '' && /circle\(150%/.test(st.css) && st.attr === 'off', JSON.stringify(st));
  const mode = page.locator(L('[role=radiogroup][aria-label=Mode]'));
  await mode.locator('[role=radio]').nth(1).click();
  await sleep(150);
  const jumped = await mode.evaluate((g) => { const blob = g.querySelector('span'); const m = /inset\(0(?:px)? ([\d.]+)px 0(?:px)? ([\d.]+)px/.exec(blob.style.clipPath); const o = g.querySelectorAll('[role=radio]')[1]; const pad = parseFloat(getComputedStyle(blob).left); return Math.abs(+m[2] - (o.offsetLeft - pad)); });
  check('tier "off": segmented blob jumps straight to the option', jumped < 0.6, `${jumped}px off`);
  await ctx.close();
}

/* ------------------------------------------------------------------ narrow screen / edge flip */
{
  const { ctx, page } = await open({ width: 390, height: 700 });
  const trig = page.locator(L('[data-testid=menu-light]'));
  await trig.click();
  await sleep(900);
  const r = await page.evaluate(() => { const p = document.querySelector('[role=menu]'); const b = p.getBoundingClientRect(); return { l: b.left, r: b.right, vw: innerWidth }; });
  check('phone width: menu is clamped inside the viewport', r.l >= 7.5 && r.r <= r.vw - 7.5, JSON.stringify(r));
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/phone-menu.png` });
  await page.keyboard.press('Escape');
  await sleep(1200);
  const noScroll = await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1);
  check('phone width: no horizontal page scroll', noScroll);
  await ctx.close();
}

await browser.close();
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);

// Real-browser checks for the showpiece buttons and the loader. BASE_URL / SHOTS env as in verify.mjs.
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const BASE = process.env.BASE_URL || 'http://localhost:4173';
const SHOTS = process.env.SHOTS || '/tmp';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : (fail++, console.log('FAIL', m)); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const run = async (reduced) => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 1100 }, reducedMotion: reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.addInitScript(() => { window.__n = 0; const r = window.requestAnimationFrame.bind(window); window.requestAnimationFrame = (cb) => { window.__n++; return r(cb); }; });
  await page.goto(BASE);
  await page.waitForSelector('[data-testid=lb-scan-light]');
  const tag = reduced ? 'reduced' : 'full';
  const st = (id) => page.getAttribute(`[data-testid=${id}]`, 'data-status');

  for (const theme of ['light', 'dark']) {
    for (const k of ['scan', 'import', 'export', 'confirm', 'continue', 'create']) {
      const id = `lb-${k}-${theme}`;
      ok((await st(id)) === 'idle', `${tag} ${id} starts idle`);
      const box = await page.locator(`[data-testid=${id}]`).boundingBox();
      ok(Math.abs(box.height - 44) < 1 && Math.abs(box.width - 44 * 4.1667) < 2, `${tag} ${id} size ${box.width}x${box.height}`);
    }
  }

  // each kind: click, see busy (not continue: it goes straight back), reach done/idle, back to idle
  for (const k of ['scan', 'import', 'export', 'confirm', 'create']) {
    const id = `lb-${k}-light`;
    await page.click(`[data-testid=${id}]`);
    await sleep(120);
    ok((await st(id)) === 'busy', `${tag} ${k} busy after click`);
    if (k === 'import' && !reduced) {
      await sleep(900);
      await page.screenshot({ path: `${SHOTS}/sp-${tag}-import-busy.png`, clip: await page.locator(`[data-testid=show-light]`).boundingBox() });
    }
    await page.waitForFunction((i) => document.querySelector(`[data-testid=${i}]`).getAttribute('data-status') === 'done', id, { timeout: 12000 }).catch(() => {});
    ok((await st(id)) === 'done', `${tag} ${k} reaches done`);
    if (k === 'confirm' || k === 'create') await page.screenshot({ path: `${SHOTS}/sp-${tag}-${k}-done.png`, clip: await page.locator(`[data-testid=show-light]`).boundingBox() });
    await page.waitForFunction((i) => document.querySelector(`[data-testid=${i}]`).getAttribute('data-status') === 'idle', id, { timeout: 6000 }).catch(() => {});
    ok((await st(id)) === 'idle', `${tag} ${k} returns to idle`);
  }
  // continue
  await page.click('[data-testid=lb-continue-dark]');
  await sleep(60);
  ok((await st('lb-continue-dark')) === 'busy', `${tag} continue busy`);
  await page.waitForFunction(() => document.querySelector('[data-testid=lb-continue-dark]').getAttribute('data-status') === 'idle', null, { timeout: 5000 }).catch(() => {});
  ok((await st('lb-continue-dark')) === 'idle', `${tag} continue returns`);

  // async wiring: promise + progress, success then failure
  const a = 'lb-async-light';
  await page.click(`[data-testid=${a}]`);
  await sleep(150);
  ok((await st(a)) === 'busy', `${tag} async busy`);
  await sleep(1200);
  ok((await st(a)) === 'busy', `${tag} async still busy while the promise is pending`);
  await page.waitForFunction((i) => document.querySelector(`[data-testid=${i}]`).getAttribute('data-status') === 'done', a, { timeout: 12000 }).catch(() => {});
  ok((await st(a)) === 'done', `${tag} async resolves → done`);
  await page.waitForFunction((i) => document.querySelector(`[data-testid=${i}]`).getAttribute('data-status') === 'idle', a, { timeout: 6000 }).catch(() => {});
  await page.check('[data-testid=fail-light]');
  await page.click(`[data-testid=${a}]`);
  await page.waitForFunction((i) => document.querySelector(`[data-testid=${i}]`).getAttribute('data-status') === 'error', a, { timeout: 14000 }).catch(() => {});
  ok((await st(a)) === 'error', `${tag} async rejects → error`);
  await sleep(300);
  await page.screenshot({ path: `${SHOTS}/sp-${tag}-error.png`, clip: await page.locator(`[data-testid=show-light]`).boundingBox() });
  ok((await page.textContent('[data-testid=show-light] [role=status]')) !== undefined, `${tag} live region exists`);

  // sleeping: after everything settles, no frames run
  await sleep(8000);
  const n1 = await page.evaluate(() => window.__n);
  await sleep(1000);
  const n2 = await page.evaluate(() => window.__n);
  ok(n2 === n1, `${tag} everything asleep after the runs: ${n1}→${n2} frames`);

  // keyboard: Enter on a focused button runs it
  await page.focus('[data-testid=lb-scan-dark]');
  await page.keyboard.press('Enter');
  await sleep(150);
  ok((await st('lb-scan-dark')) === 'busy', `${tag} Enter starts scan`);

  await page.check('[data-testid=loader-run-light]');
  // loader: path changes over time when full, static when reduced
  const d1 = await page.getAttribute('[data-testid=loader-light] svg path:last-child', 'd');
  await sleep(2000);
  const d2 = await page.getAttribute('[data-testid=loader-light] svg path:last-child', 'd');
  ok(reduced ? d1 === d2 : d1 !== d2, `${tag} loader ${reduced ? 'is still' : 'moves'}`);
  await page.screenshot({ path: `${SHOTS}/sp-${tag}-dark.png`, clip: await page.locator(`[data-testid=show-dark]`).boundingBox() });

  ok(errors.length === 0, `${tag} no console errors: ${errors.slice(0, 3).join(' | ')}`);
  await browser.close();
};

await run(false);
await run(true);
console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);

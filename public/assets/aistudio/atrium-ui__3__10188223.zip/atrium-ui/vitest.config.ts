import { defineConfig } from 'vitest/config';

// The engine tests are pure TypeScript (no DOM needed).
export default defineConfig({
  test: { globals: true, environment: 'node', include: ['src/**/*.test.ts'] },
});

// Real-browser checks for Sidebar + AppShell. BASE_URL=http://localhost:4174, SHOTS=dir
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const BASE = process.env.BASE_URL || 'http://localhost:4174';
const SHOTS = process.env.SHOTS || '/tmp';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : (fail++, console.log('FAIL', m)); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const run = async (reduced) => {
  const tag = reduced ? 'reduced' : 'full';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 800 }, reducedMotion: reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.addInitScript(() => {
    window.__n = 0; const r = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (cb) => { window.__n++; return r(cb); };
  });
  await page.goto(BASE);
  await page.waitForSelector('nav[aria-label="Main navigation"]');
  await sleep(400);
  const nav = page.locator('nav[aria-label="Main navigation"]');
  const edge = nav.locator('button[aria-expanded]');
  const main = page.locator('main');
  const openVar = () => nav.evaluate((n) => parseFloat(n.style.getPropertyValue('--open') || '0'));
  const mainBox = () => main.boundingBox();

  // ---- idle cost
  const a = await page.evaluate(() => window.__n); await sleep(800);
  ok((await page.evaluate(() => window.__n)) === a, `${tag} idle: zero frames`);

  // ---- sidebar: rail takes layout width, opening does not move the page
  const rail = await nav.boundingBox();
  ok(Math.abs(rail.width - 60) < 1, `${tag} rail is 60px wide (${rail.width})`);
  const m0 = await mainBox();
  const iconBefore = await nav.locator('button[aria-label="Adhérents"] svg').boundingBox();
  await edge.click();
  await sleep(120);
  const mid = await openVar();
  ok(reduced ? mid === 1 : mid > 0 && mid < 1.2, `${tag} --open animates (mid ${mid})`);
  let peak = mid;
  for (let i = 0; i < 20; i++) { peak = Math.max(peak, await openVar()); await sleep(30); }
  await sleep(500);
  ok(Math.abs((await openVar()) - 1) < 0.01, `${tag} settles at 1`);
  if (!reduced) ok(peak > 1.03 && peak < 1.15, `${tag} one soft overshoot (peak ${peak.toFixed(3)})`);
  const m1 = await mainBox();
  ok(Math.abs(m1.x - m0.x) < 0.5 && Math.abs(m1.width - m0.width) < 0.5, `${tag} page does not reflow when the sidebar opens`);
  const iconAfter = await nav.locator('button[aria-label="Adhérents"] svg').boundingBox();
  ok(Math.abs(iconAfter.x - iconBefore.x) < 0.5, `${tag} icons never move`);
  const label = await nav.locator('button[aria-label="Adhérents"] span[aria-hidden]').evaluate((e) => getComputedStyle(e).opacity);
  ok(parseFloat(label) > 0.95, `${tag} label visible when open (${label})`);
  await page.screenshot({ path: `${SHOTS}/shell-${tag}-open.png` });
  const s1 = await page.evaluate(() => window.__n); await sleep(900);
  ok((await page.evaluate(() => window.__n)) === s1, `${tag} open sidebar at rest: zero frames`);

  // Escape closes; outside click closes
  await page.keyboard.press('Escape'); await sleep(900);
  ok((await openVar()) < 0.01, `${tag} Escape closes`);
  await edge.click(); await sleep(700);
  await page.mouse.click(900, 400); await sleep(900);
  ok((await openVar()) < 0.01, `${tag} outside click closes`);
  // interrupt mid-flight
  await edge.click(); await sleep(90); await edge.click(); await sleep(1000);
  ok((await openVar()) < 0.01, `${tag} interruptible (closed again)`);

  // ---- top bar
  const bar = page.locator('main').locator('xpath=preceding::div[contains(@class,"bar")][1]').first();
  const barBox0 = await page.locator('[class*="bar"]').first().boundingBox().catch(() => null);
  const top0 = (await mainBox()).y;
  await page.mouse.move(900, 400);
  await page.evaluate(() => document.querySelector('main').scrollTo(0, 300));
  await sleep(150);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'hidden', `${tag} scroll down hides the bar`);
  await sleep(1000);
  const top1 = (await mainBox()).y;
  ok(top1 < top0 - 40, `${tag} page card moved up and took the space (${top0}→${top1})`);
  await page.screenshot({ path: `${SHOTS}/shell-${tag}-hidden.png` });
  const f1 = await page.evaluate(() => window.__n); await sleep(900);
  ok((await page.evaluate(() => window.__n)) === f1, `${tag} hidden bar at rest: zero frames`);
  const vis = await page.evaluate(() => getComputedStyle(document.querySelector('[data-bar] > div:nth-child(2) > div')).visibility);
  ok(vis === 'hidden', `${tag} hidden bar is not focusable (visibility ${vis})`);
  // scroll up shows
  await page.evaluate(() => document.querySelector('main').scrollBy(0, -80));
  await sleep(1200);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'shown', `${tag} scroll up shows the bar`);
  await sleep(600);
  const top2 = (await mainBox()).y;
  ok(Math.abs(top2 - top0) < 1, `${tag} card back at its place (${top2} vs ${top0})`);
  // hover top edge
  await page.evaluate(() => document.querySelector('main').scrollTo(0, 500)); await sleep(1500);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'hidden', `${tag} hidden again`);
  await page.mouse.move(700, 2); await page.mouse.move(701, 3); await sleep(900);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'shown', `${tag} hover on the top edge shows it`);
  // bring the bar back, then switch auto-hide off
  await page.evaluate(() => document.querySelector('main').scrollTo(0, 900)); await sleep(1500);
  await page.evaluate(() => document.querySelector('main').scrollBy(0, -80)); await sleep(1500);
  await page.locator('[data-testid=auto-toggle]').click(); await sleep(300);
  // manual hide button
  await page.evaluate(() => document.querySelector('main').scrollTo(0, 0)); await sleep(600);
  if (await page.getAttribute('[data-bar]', 'data-bar') === 'hidden') { await page.getByText('Show top bar').click(); await sleep(1200); }
  await page.locator('[data-testid=hide-bar]').click(); await sleep(1200);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'hidden', `${tag} Hide bar button works`);
  await page.getByText('Show top bar').focus();
  await page.keyboard.press('Enter'); await sleep(1200);
  ok(await page.getAttribute('[data-bar]', 'data-bar') === 'shown', `${tag} keyboard: Show top bar button works`);
  await page.screenshot({ path: `${SHOTS}/shell-${tag}-shown.png` });
  await sleep(2000);
  const z1 = await page.evaluate(() => window.__n); await sleep(900);
  ok((await page.evaluate(() => window.__n)) === z1, `${tag} everything asleep`);
  ok(errors.length === 0, `${tag} no console errors: ${errors.slice(0, 3).join(' | ')}`);
  await browser.close();
};
await run(false);
await run(true);
console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);

'use client';

import { useState } from 'react';
import type { ReactNode } from 'react';
import { AppShell, AtriumLogo, Button, IconButton, Segmented, Sidebar, Toggle } from '../../atrium';
import './shell.css';

const I = ({ d }: { d: string }): ReactNode => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d={d} />
  </svg>
);
const icons = {
  home: I({ d: 'M4 11l8-7 8 7v9H4zM10 20v-6h4v6' }),
  users: I({ d: 'M16 20v-1a4 4 0 00-4-4H8a4 4 0 00-4 4v1M10 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM20 20v-1a4 4 0 00-3-3.9M16 4.2a3.5 3.5 0 010 6.6' }),
  clip: I({ d: 'M9 4h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h6' }),
  history: I({ d: 'M4 12a8 8 0 102.5-5.8M4 4v5h5M12 8v4l3 2' }),
  bag: I({ d: 'M6 8h12l1 12H5zM9 8V6a3 3 0 016 0v2' }),
  cal: I({ d: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4' }),
  wallet: I({ d: 'M4 7h14a2 2 0 012 2v10H6a2 2 0 01-2-2zM4 7l12-3v3M16 14h2' }),
  gear: I({ d: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1a7 7 0 00-2-1l-.5-2h-4L10 7a7 7 0 00-2 1L6 7l-2 4 2 1a7 7 0 000 2l-2 1 2 4 2-1a7 7 0 002 1l.5 2h4l.5-2a7 7 0 002-1l2 1 2-4-2-1a7 7 0 000-2z' }),
  search: I({ d: 'M11 18a7 7 0 100-14 7 7 0 000 14zM20 20l-4-4' }),
  refresh: I({ d: 'M20 12a8 8 0 11-2.5-5.8M20 4v5h-5' }),
  bell: I({ d: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4' }),
  plus: I({ d: 'M12 5v14M5 12h14' }),
};

const ITEMS = [
  { id: 'home', label: 'Accueil', icon: icons.home },
  { id: 'members', label: 'Adhérents', icon: icons.users },
  { id: 'reg', label: 'Inscriptions', icon: icons.clip, badge: 3 },
  { id: 'audit', label: 'Historique & Audit', icon: icons.history },
  { id: 'shop', label: 'Boutique Pro-Shop', icon: icons.bag },
  { id: 'plan', label: 'Planning des séances', icon: icons.cal },
  { id: 'fin', label: 'Finances & Équipe', icon: icons.wallet },
  { id: 'team', label: 'Équipe', icon: icons.users },
  { id: 'set', label: 'Paramètres du système', icon: icons.gear },
];

const ROWS = Array.from({ length: 28 }, (_, i) => ({
  name: ['Amira Cherif', 'Sara Bouzid', 'Yacine Mebarki', 'Lina Haddad', 'Karim Belaid', 'Nour Amrani'][i % 6],
  plan: ['Full Access Monthly', 'Day Pass', 'Annual', 'Student'][i % 4],
  amount: `${(4500 + ((i * 937) % 4000)).toLocaleString('fr-FR')} DZD`,
}));

export default function ShellDemo() {
  const [active, setActive] = useState('members');
  const [hidden, setHidden] = useState(false);
  const [auto, setAuto] = useState(true);
  const [mode, setMode] = useState('manager');

  return (
    <div className="shell-demo" data-atrium-theme="dark">
      <AppShell
        barHidden={hidden}
        onBarHiddenChange={setHidden}
        autoHide={auto}
        sidebar={
          <Sidebar
            items={ITEMS}
            activeId={active}
            onSelect={setActive}
            expandOn="click"
            brand={{ mark: <AtriumLogo variant="mark" height={24} style={{ color: '#E8643F' }} />, title: 'ATRIUM' }}
            footer="NCH PLATFORM"
          />
        }
        topbar={
          <>
            <span className="crumbs">Accueil <i>›</i> Adhérents <i>›</i> <b>Amira Cherif</b></span>
            <span className="grow" />
            <Segmented
              aria-label="Mode"
              value={mode}
              onValueChange={setMode}
              options={[
                { value: 'manager', label: 'Gérant Salle' },
                { value: 'scan', label: 'Accueil & Scan' },
              ]}
              size="sm"
            />
            <span className="grow" />
            <label className="auto">
              <Toggle aria-label="Hide the top bar when scrolling down" checked={auto} onCheckedChange={setAuto} size="sm" data-testid="auto-toggle" />
              <span>Auto-hide</span>
            </label>
            <Button tone="soft" size="sm" onClick={() => setHidden(true)} data-testid="hide-bar">Hide bar</Button>
            <IconButton aria-label="Search" icon={icons.search} size="sm" />
            <IconButton aria-label="Refresh" icon={icons.refresh} kick="spin" size="sm" />
            <IconButton aria-label="Notifications, 1 unread" icon={icons.bell} badge={1} size="sm" />
          </>
        }
      >
        <div className="page">
          <header className="page-head">
            <h1>Adhérents</h1>
            <Button tone="accent" size="md" leading={icons.plus}>Ajouter Adhérent</Button>
          </header>
          <p className="hint">
            Scroll this page down: the top bar slides away and the page takes its space. Scroll up, hover the very top edge, or press
            Tab to bring it back. Click the orange handle on the sidebar (or press Esc to close it).
          </p>
          <div className="stats">
            <div><span>Base active adhérents</span><b>2</b></div>
            <div><span>Alertes de renouvellement</span><b>0</b></div>
            <div><span>Adhésions du mois</span><b className="acc">+2</b></div>
          </div>
          <ul className="rows">
            {ROWS.map((r, i) => (
              <li key={i}>
                <span className="av">{r.name[0]}</span>
                <span className="nm">{r.name}</span>
                <span className="pl">{r.plan}</span>
                <span className="am">{r.amount}</span>
              </li>
            ))}
          </ul>
        </div>
      </AppShell>
    </div>
  );
}

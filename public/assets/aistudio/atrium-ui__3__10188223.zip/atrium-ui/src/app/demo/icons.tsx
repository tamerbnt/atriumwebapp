/*
 * Demo-only icons, same 24-px outline style as Lucide so the demo has no dependency.
 * In your app, use lucide-react: `<Plus />` works as is, the controls restyle any inline <svg>.
 */
import type { ReactNode } from 'react';

const I = ({ d }: { d: string }): ReactNode => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d={d} />
  </svg>
);

export const Plus = () => I({ d: 'M12 5v14M5 12h14' });
export const Sparkles = () => I({ d: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z' });
export const Home = () => I({ d: 'M4 11l8-7 8 7v9H4zM10 20v-6h4v6' });
export const ChevronDown = () => I({ d: 'M6 9l6 6 6-6' });
export const Zap = () => I({ d: 'M13 3L5 14h6l-1 7 8-11h-6z' });
export const List = () => I({ d: 'M8 7h12M8 12h12M8 17h12M4 7h.01M4 12h.01M4 17h.01' });
export const Grid = () => I({ d: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z' });
export const Refresh = () => I({ d: 'M20 12a8 8 0 11-2.5-5.8M20 4v5h-5' });
export const Bell = () => I({ d: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4' });
export const Lock = () => I({ d: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3' });
export const Pulse = () => I({ d: 'M3 12h4l3-8 4 16 3-8h4' });
export const Rocket = () => I({ d: 'M5 19c0-3 2-5 4-5M14 4c4 0 6 2 6 6-3 4-6 5-9 5l-2-2c0-3 1-6 5-9zM9 15l-3 5' });
export const Gift = () => I({ d: 'M4 8h16v12H4zM12 8v12M4 12h16M8 8a2.5 2.5 0 010-5c2 0 4 2.5 4 5 0-2.5 2-5 4-5a2.5 2.5 0 010 5' });
export const LogOut = () => I({ d: 'M10 4H5v16h5M15 8l4 4-4 4M19 12H9' });
